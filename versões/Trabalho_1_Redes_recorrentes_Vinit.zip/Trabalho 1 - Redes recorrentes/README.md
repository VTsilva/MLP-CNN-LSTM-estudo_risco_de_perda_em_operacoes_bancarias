# Trabalho 1 — Redes recorrentes

Projeto acadêmico de previsão de séries temporais com redes neurais, utilizando o conjunto de indicadores do **National Financial Conditions Index (NFCI)**, do Federal Reserve Bank of Chicago.

## Objetivo de trabalho

Comparar arquiteturas de redes neurais na previsão de um passo à frente do subíndice de crédito (`Credit`), em experimentos univariados e multivariados, conforme o roteiro fornecido pelo professor.

Título provisório:

> Comparação de arquiteturas MLP, CNN e LSTM na previsão de condições de crédito: uma abordagem de séries temporais aplicada ao estudo do risco de perda em operações bancárias.

O título é provisório e poderá ser ajustado para refletir com precisão o escopo final e os modelos efetivamente avaliados.

## Como começar em uma nova sessão ou com outro agente

1. Leia `contexto_ia/00_LEIA_PRIMEIRO.md`.
2. Leia os documentos indicados em `contexto_ia/` para conhecer o objetivo, as decisões e o estado atual.
3. Consulte o notebook original em `arquivos_de_contexto/` para conferir as instruções acadêmicas completas.
4. Consulte `planos_ia/` antes de executar tarefas planejadas e `skills/` quando houver procedimentos reutilizáveis.
5. Não modifique `data/raw/` nem o notebook original do professor. Crie versões derivadas nas camadas apropriadas e trabalhe em uma cópia do notebook quando chegar a etapa de desenvolvimento.

## Estrutura

- `contexto_ia/`: conhecimento consolidado, decisões, metodologia e estado do projeto.
- `planos_ia/`: planos de execução de tarefas.
- `skills/`: procedimentos reutilizáveis para agentes e IAs.
- `data/raw/`, `bronze/`, `silver/`, `gold/`: organização dos dados em arquitetura Medallion.
- `IMGs/`: imagens, gráficos e diagramas do projeto.
- `arquivos_de_contexto/`: enunciados, materiais de aula e arquivos originais de referência.
- Raiz: entregáveis finais, como o notebook desenvolvido e eventuais relatórios de apoio.

## Estado inicial

A base original do NFCI e o notebook-modelo do professor já estão armazenados. A documentação inicial foi criada a partir do que foi definido até 07/11/2026. A análise exploratória, o pipeline de dados e os experimentos de modelagem ainda não foram executados.

## Entrega acadêmica

O notebook do professor informa que a entrega será um único arquivo `.ipynb`, salvo no padrão `<nome_do_estudante>_trabalho1.ipynb`. Os demais diretórios deste projeto organizam os dados e o processo de desenvolvimento; não substituem a instrução formal de entrega.
