# MLP-CNN-LSTM — Estudo de risco de perda em operações bancárias

**Repositório:** [VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias](https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias)

**Título acadêmico:**

> Comparação de arquiteturas MLP, CNN e LSTM na previsão de condições de crédito: uma abordagem de séries temporais aplicada ao estudo do risco de perda em operações bancárias.

## Objetivo

Comparar redes neurais para previsão de um passo à frente do subíndice `Credit`, presente no conjunto de indicadores do National Financial Conditions Index (NFCI), do Federal Reserve Bank of Chicago. O trabalho contempla dois experimentos: previsão univariada (somente histórico de `Credit`) e previsão multivariada (histórico de `Credit` e variáveis explicativas adicionais), seguindo os modelos e requisitos do roteiro do professor.

A motivação está relacionada ao contexto de risco de crédito e perdas bancárias. **O alvo estatístico é `Credit`, não LGD**. Portanto, os resultados não devem ser descritos como estimação direta de LGD.

## Comece por aqui (IA, Devin ou pessoa colaboradora)

1. Leia `AGENTS.md`.
2. Leia `contexto_ia/00_LEIA_PRIMEIRO.md` e os documentos indicados.
3. Consulte o notebook original preservado em `arquivos_de_contexto/`.
4. Confira o estado do Git e as alterações locais antes de modificar arquivos.
5. Consulte o plano correspondente em `planos_ia/` e as Skills aplicáveis em `skills/`.

## Estrutura do projeto

| Diretório/arquivo | Finalidade |
|---|---|
| `AGENTS.md` | Regras operacionais para agentes e colaboradores |
| `victor_silva_trabalho1.ipynb` | Notebook principal de trabalho e futura entrega acadêmica |
| `contexto_ia/` | Memória documental consolidada: objetivo, estado, decisões, metodologia, dados e referências |
| `planos_ia/` | Planos de execução, status, critérios e histórico das tarefas |
| `skills/` | Procedimentos reutilizáveis para agentes de IA |
| `data/raw/` | Dados originais, preservados sem transformação |
| `data/bronze/` | Ingestão técnica e padronização inicial |
| `data/silver/` | Dados validados e tratados |
| `data/gold/` | Conjuntos finais para análise e modelagem |
| `IMGs/` | Gráficos, diagramas e imagens do trabalho |
| `arquivos_de_contexto/` | Notebook original do professor, enunciado e materiais de referência |
| `versões/` | Snapshot histórico antigo, não autoritativo |
| raiz | Notebook final e demais entregáveis de desenvolvimento |

## Dados recebidos e verificados

Arquivo: `data/raw/nfci-data-series-csv.csv`.

- 2.913 observações semanais.
- 7 colunas: uma data e seis indicadores numéricos.
- Período no arquivo: 08/01/1971 a 30/10/2026.
- Sem datas duplicadas ou valores ausentes na inspeção realizada.
- Intervalo entre observações consecutivas: 7 dias.
- Target escolhido: `Credit`.

Confira `contexto_ia/dicionario_dados.md` para o dicionário e `contexto_ia/estado_atual.md` para o que já foi e ainda não foi executado.

## Notebook principal e entrega acadêmica

O notebook principal de trabalho está na raiz: `victor_silva_trabalho1.ipynb`. Ele organiza o relatório acadêmico, executa a ingestão/auditoria e a EDA inicial, documenta a divisão temporal e contém os espaços de desenvolvimento dos 8 modelos univariados e 8 multivariados exigidos. O notebook foi executado até o fim sem erros de célula; ainda não há treinamento de modelos nem resultados preditivos.

A instrução do professor determina a entrega de um único notebook `.ipynb`, nomeado `<nome_do_estudante>_trabalho1.ipynb`. O notebook original do professor permanece intacto em `arquivos_de_contexto/` e serve como roteiro de referência. O notebook principal poderá evoluir até se tornar a entrega final após implementação, treinamento, análise e revisão.

## Fonte principal

- Chicago Fed — NFCI: https://www.chicagofed.org/research/data/nfci/current-data
- Repositório GitHub do projeto: https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias
