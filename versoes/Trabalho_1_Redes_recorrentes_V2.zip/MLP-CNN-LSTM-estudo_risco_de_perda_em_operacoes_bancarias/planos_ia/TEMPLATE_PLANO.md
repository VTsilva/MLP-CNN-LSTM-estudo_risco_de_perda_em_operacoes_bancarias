# [Nome da tarefa]

- **Data de criação:** AAAA-MM-DD
- **Status:** Proposto / Planejado / Em andamento / Concluído / Bloqueado / Cancelado
- **Responsável:** [preencher]

## 1. Objetivo

[Resultado esperado e como será verificado.]

## 2. Contexto e decisões relacionadas

[Referenciar arquivos em `contexto_ia/` e decisões relevantes.]

## 3. Escopo

### Incluído
- [item]

### Fora do escopo
- [item]

## 4. Entradas e saídas

| Tipo | Caminho | Descrição |
|---|---|---|
| Entrada | [caminho] | [descrição] |
| Saída | [caminho] | [descrição] |

## 5. Etapas de execução

1. [etapa]
2. [etapa]
3. [etapa]

## 6. Critérios de conclusão e qualidade

- [critério verificável]

## 7. Riscos e dependências

- [risco/dependência]

## 8. Registro de execução

[Preencher somente após a execução. Registrar arquivos modificados, comandos/testes, resultados e pendências.]
