# Versões históricas

Esta pasta preserva um ZIP histórico que veio dentro do snapshot enviado pelo responsável. Ele representa uma versão anterior da estrutura e **não é a fonte de verdade do projeto atual**.

A versão autoritativa é a árvore atual na raiz deste repositório, documentada por `README.md`, `AGENTS.md` e `contexto_ia/`. Não extrair ou usar o ZIP histórico para substituir arquivos atuais, a menos que o responsável solicite recuperação de uma versão anterior.
