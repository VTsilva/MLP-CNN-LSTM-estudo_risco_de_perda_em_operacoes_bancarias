# Visão geral do projeto

## Identificação

- **Nome do repositório/projeto:** `MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias`
- **Repositório GitHub:** https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias
- **Título acadêmico:** Comparação de arquiteturas MLP, CNN e LSTM na previsão de condições de crédito: uma abordagem de séries temporais aplicada ao estudo do risco de perda em operações bancárias.
- **Base:** arquivo com indicadores semanais do National Financial Conditions Index (NFCI), Chicago Fed.
- **Variável-alvo:** `Credit` (Credit Subindex).
- **Data desta consolidação:** 07/11/2026.

## Descrição resumida

O estudo compara arquiteturas de redes neurais na previsão de um passo à frente do subíndice `Credit`, em duas abordagens: (1) univariada, utilizando somente o histórico de `Credit`; e (2) multivariada, utilizando o histórico de `Credit` juntamente com outros indicadores disponíveis no dataset. O trabalho seguirá o roteiro fornecido pelo professor, incluindo análise temporal, divisão treino/validação/teste, seleção manual de épocas com base em curvas e comparação de modelos.

## Motivação financeira

O interesse inicial surgiu do tema LGD (*Loss Given Default*), uma das componentes do risco de crédito. A base pública selecionada, entretanto, não contém LGD observada por contrato nem recuperação de crédito. Ela contém indicadores agregados de condições financeiras e de crédito dos Estados Unidos.

A previsão de `Credit` pode ser discutida como estudo de condições de crédito no ambiente macrofinanceiro que contextualiza riscos e perdas bancárias. **Não é uma previsão direta de PD, LGD, EAD ou perda esperada.** Não se deve atribuir causalidade entre o NFCI e LGD sem um desenho causal específico e dados adequados.

## Pergunta de pesquisa

Como diferentes arquiteturas de redes neurais se comparam na previsão de um passo à frente do subíndice de condições de crédito (`Credit`), utilizando somente seu histórico (previsão univariada) ou incorporando outras variáveis do conjunto NFCI (previsão multivariada)?

## Objetivo geral

Implementar e comparar modelos de redes neurais recorrentes e outras arquiteturas indicadas no roteiro acadêmico para prever o valor imediatamente seguinte de `Credit`, avaliando as diferenças entre experimentos univariados e multivariados.

## Escopo

1. Descrever a fonte, a série, o período, a frequência e as variáveis.
2. Validar os dados e executar análise exploratória temporal.
3. Identificar tendências, ciclos e padrões relevantes, sem pressupor sazonalidade.
4. Dividir cronologicamente os dados em 70% treino, 20% validação e 10% teste.
5. Definir e justificar o tamanho da janela móvel.
6. Treinar e comparar todos os modelos univariados indicados.
7. Repetir o processo com os modelos multivariados indicados, prevendo somente `Credit`.
8. Acompanhar custo e métrica em treino e validação; escolher manualmente a quantidade de épocas por inspeção dos gráficos.
9. Calcular resultados de treino, validação e teste e comparar os modelos.
10. Produzir notebook final claro, profissional, reproduzível e integralmente executável.

## Limites explícitos

- Não há, nesta base, target de LGD individual ou recuperação de operações.
- Não há experimento causal estabelecido.
- Não existe ainda resultado de EDA ou treinamento; qualquer resultado futuro deve ser calculado e armazenado no notebook.
- O projeto é acadêmico e não deve ser apresentado como modelo de produção ou ferramenta de decisão de crédito.
