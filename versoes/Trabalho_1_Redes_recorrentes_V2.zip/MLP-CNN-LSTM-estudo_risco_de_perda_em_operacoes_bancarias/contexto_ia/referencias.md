# Referências e fontes do projeto

## Fonte de dados

- **Federal Reserve Bank of Chicago.** National Financial Conditions Index (NFCI) — dados, documentação e metodologia. https://www.chicagofed.org/research/data/nfci/current-data. Acesso/arquivo utilizado no projeto: CSV recebido e preservado em `data/raw/nfci-data-series-csv.csv`.

## Repositório e materiais do projeto

- **Repositório GitHub do estudo.** https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias
- **Notebook original do professor.** `arquivos_de_contexto/trabalho 1 previsao univariada e multivariada passo unico.ipynb` (material local fornecido para a disciplina; manter sem alterações).
- **Enunciado consolidado.** `arquivos_de_contexto/enunciado_e_requisitos.md`.

## Referências metodológicas a incorporar

Ao escrever o notebook final, adicionar referências específicas para:

- documentação das arquiteturas MLP, CNN 1D, LSTM, CNN-LSTM e ConvLSTM efetivamente implementadas;
- material do curso IAD-012 usado para as métricas, treinamento e identificação do overfitting;
- métodos de análise de séries temporais (tendência, ciclos, autocorrelação e estacionariedade) efetivamente utilizados;
- métricas de regressão e critérios de avaliação escolhidos.

Não inserir referências bibliográficas que não tenham sido consultadas. Registrar URL, autoria, título e data de acesso quando apropriado.
