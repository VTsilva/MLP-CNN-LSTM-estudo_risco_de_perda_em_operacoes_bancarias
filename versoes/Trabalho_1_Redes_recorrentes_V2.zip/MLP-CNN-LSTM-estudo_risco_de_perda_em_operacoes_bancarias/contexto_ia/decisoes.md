# Registro de decisões e premissas

Os status distinguem o que já foi decidido ou verificado do que ainda é proposta. Não promover itens provisórios a confirmados sem evidência ou autorização.

| ID | Tema | Decisão/entendimento | Status | Observação |
|---|---|---|---|---|
| D-001 | Tema | Estudar previsão de condições de crédito no contexto financeiro/bancário. | Confirmado | Motivação inicial relacionada ao risco de perda e LGD. |
| D-002 | Nome do projeto | `MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias`. | Confirmado | Nome do repositório e identidade do projeto. |
| D-003 | Repositório | Utilizar o repositório pessoal `https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias`. | Confirmado | `origin` aparece configurado no snapshot recebido; não houve push nesta atualização. |
| D-004 | Título acadêmico | “Comparação de arquiteturas MLP, CNN e LSTM na previsão de condições de crédito: uma abordagem de séries temporais aplicada ao estudo do risco de perda em operações bancárias.” | Confirmado | Descrição/título fornecidos pelo responsável. |
| D-005 | Base | Utilizar `data/raw/nfci-data-series-csv.csv`, conjunto de indicadores NFCI do Chicago Fed. | Confirmado | A estrutura do arquivo foi inspecionada. |
| D-006 | Target | Prever `Credit` (Credit Subindex). | Confirmado | Target escolhido pelo responsável; não é uma LGD. |
| D-007 | Frequência | Manter frequência semanal original, sem subamostragem inicial. | Provisório | Reavaliar apenas se a EDA e a justificativa acadêmica indicarem necessidade. |
| D-008 | Variáveis multivariadas | Avaliar `Credit`, `Risk`, `Leverage` e `Nonfinancial_Leverage` como entradas para prever `Credit`. | Provisório | O histórico do target deve fazer parte da janela; selecionar features finais após EDA. |
| D-009 | Índices agregados | Excluir `NFCI` e `ANFCI` do desenho multivariado inicial. | Provisório | Sobreposição com componentes e risco de redundância; eventual comparação só como experimento justificado. |
| D-010 | Horizonte | Prever o valor de `Credit` imediatamente seguinte à janela de entrada (um passo à frente). | Confirmado | Exigência do roteiro acadêmico. |
| D-011 | Divisão | Dividir cronologicamente em 70% treino, 20% validação e 10% teste. | Confirmado | Exigência do roteiro. Treino inicial, validação intermediária e teste final. |
| D-012 | Janela móvel | Definir o comprimento após caracterização temporal e consideração do conteúdo das aulas. | Pendente | Não assumir 52 semanas sem evidência/decisão. |
| D-013 | Modelos univariados | Implementar os 8 modelos indicados no Passo 3 do notebook do professor. | Confirmado | Lista documentada em `metodologia_provisoria.md`. |
| D-014 | Modelos multivariados | Implementar os 8 modelos indicados no Passo 4 do notebook do professor. | Confirmado | Lista documentada em `metodologia_provisoria.md`. |
| D-015 | Épocas | Acompanhar curvas de treinamento e validação e escolher manualmente o número de épocas por inspeção. | Confirmado | Exigência do roteiro; registrar critério aplicado para cada arquitetura. |
| D-016 | Acurácia | A definição operacional da “acurácia” em regressão ainda precisa ser verificada. | Pendente | Não substituir nem inventar a métrica sem conferir o material de IAD-012/aulas. Reportar também métricas adequadas de regressão. |
| D-017 | Embaralhamento | Preservar cronologia ao gerar janelas; avaliar embaralhar somente amostras/janelas de treinamento no processo de ajuste. | Provisório | O roteiro menciona embaralhar treino; a implementação deve preservar a ordem dentro de cada janela e nunca embaralhar validação/teste. |
| D-018 | Escalonamento | Ajustar scalers somente no treino e aplicar sem reajuste a validação/teste. | Diretriz metodológica | Evitar vazamento de informação temporal. |
| D-019 | Arquitetura de dados | Utilizar camadas `raw`, `bronze`, `silver` e `gold`. | Confirmado | Organização do responsável pelo projeto. |
| D-020 | Entrega | A entrega acadêmica formal será um único notebook `.ipynb`, nomeado `<nome_do_estudante>_trabalho1.ipynb`. | Confirmado | Outras pastas são suporte de desenvolvimento, não substituem a entrega. |
| D-021 | Limite LGD | Não afirmar que o modelo estima LGD, PD, EAD ou perda esperada. | Confirmado | `Credit` é um índice agregado de condições de crédito. |

## Questões pendentes prioritárias

1. Qual é a definição de “acurácia” utilizada no curso para modelos de previsão contínua? Consultar material/código das aulas.
2. Qual comprimento da janela representa melhor a dinâmica e os padrões encontrados na EDA?
3. Quais colunas adicionais entrarão no multivariado? Considerar relações temporais, disponibilidade e redundância.
4. Como exatamente o professor espera que seja feito o embaralhamento do conjunto de treinamento?
5. Qual arquitetura/tensor de entrada será usada para CNN, CNN-LSTM, ConvLSTM e modelos multi-cabeça, mantendo equivalência de informação entre modelos?
6. Qual procedimento exato de retreinamento será seguido após selecionar épocas? Preservar validação e teste para avaliação e registrar a escolha.
7. Quais métricas serão comparadas e qual será o critério primário para ranquear os modelos?

## Histórico de alterações

- 07/11/2026: identidade do projeto, URL GitHub, título, requisitos do roteiro, inventário de modelos e verificações do CSV consolidados nesta documentação.


## Histórico de implementação do notebook principal

- 07/11/2026: criado `victor_silva_trabalho1.ipynb` na raiz como notebook principal de desenvolvimento. O notebook contém EDA executável, divisão temporal e scaffolding para os experimentos. A criação não altera as decisões pendentes sobre janela, definição da acurácia do curso, features definitivas e arquiteturas específicas.
