# Dicionário de dados — indicadores NFCI

## Arquivo e origem

- **Arquivo:** `data/raw/nfci-data-series-csv.csv`.
- **Fonte indicada:** Federal Reserve Bank of Chicago, National Financial Conditions Index (NFCI).
- **Página institucional:** https://www.chicagofed.org/research/data/nfci/current-data
- **Frequência observada:** semanal.
- **Período no arquivo recebido:** 08/01/1971 a 30/10/2026.
- **Formato original de data:** texto `MM/DD/YYYY`.
- **Dimensão validada:** 2.913 linhas × 7 colunas.

## Colunas

| Coluna | Descrição | Interpretação geral | Papel no projeto |
|---|---|---|---|
| `Friday_of_Week` | Data semanal de referência (sexta-feira). | Identifica o instante da observação. | Índice temporal; converter para datetime. |
| `NFCI` | National Financial Conditions Index. | Índice agregado das condições financeiras. Valores positivos indicam condições mais restritivas que a média histórica; negativos, mais flexíveis. | Fora do primeiro desenho multivariado; avaliar redundância. |
| `ANFCI` | Adjusted National Financial Conditions Index. | Versão ajustada do NFCI para considerar condições macroeconômicas. | Fora do primeiro desenho multivariado; avaliar redundância. |
| `Risk` | Risk Subindex. | Dimensão de risco nas condições financeiras; valores positivos indicam condições mais restritivas na dimensão correspondente. | Feature candidata. |
| `Credit` | Credit Subindex. | Dimensão relacionada às condições de crédito. | Target de previsão; no multivariado, o histórico de `Credit` também é entrada. |
| `Leverage` | Leverage Subindex. | Dimensão relacionada às condições de alavancagem. | Feature candidata. |
| `Nonfinancial_Leverage` | Nonfinancial Leverage Subindex. | Dimensão de alavancagem referente ao setor não financeiro, como famílias e empresas não financeiras. | Feature candidata. |

## Interpretação e cuidados

O NFCI é um indicador agregado e seus subíndices representam dimensões relacionadas das condições financeiras. O ANFCI é ajustado para o ambiente macroeconômico. As variáveis não devem ser tratadas como estatisticamente independentes apenas porque aparecem em colunas separadas.

A interpretação dos sinais deve ser conferida na documentação metodológica oficial do Chicago Fed. Em termos gerais, valores positivos representam condições mais restritivas do que a média histórica e valores negativos representam condições mais flexíveis; não significam diretamente maior/menor inadimplência ou LGD.

`Credit` mede condições de crédito, não perdas efetivamente realizadas. O arquivo não contém, nas colunas recebidas, identificador de contrato, EAD, recuperação, default individual, custos de cobrança ou LGD observada.

## Validações já realizadas

- 2.913 registros e sete colunas.
- Nenhum valor ausente nas sete colunas.
- Nenhuma data duplicada.
- 2.912 intervalos consecutivos de sete dias.
- Datas inicial/final: 08/01/1971 e 30/10/2026.
- As seis variáveis não temporais foram interpretadas como numéricas (`float64`) pela leitura tabular utilizada na verificação.

## Fonte

Chicago Fed — NFCI, metodologia e dados: https://www.chicagofed.org/research/data/nfci/current-data
