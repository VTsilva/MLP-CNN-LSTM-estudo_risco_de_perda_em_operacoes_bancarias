# Leia primeiro — memória do projeto

Este diretório é a memória documental consolidada do projeto. Ele existe para que outro agente/IA consiga continuar o trabalho sem depender do histórico de conversas.

## Ordem de leitura

1. `visao_geral.md` — identificação, objetivo, pergunta e limites do estudo.
2. `estado_atual.md` — estado real dos artefatos e atividades.
3. `decisoes.md` — decisões confirmadas, provisórias e pendentes.
4. `enunciado_e_requisitos.md` — requisitos acadêmicos extraídos do material do professor e da orientação recebida.
5. `metodologia_provisoria.md` — desenho experimental e pontos metodológicos a resolver.
6. `dicionario_dados.md` — estrutura e interpretação do CSV.
7. `referencias.md` — fontes e materiais de referência.

Leia também `AGENTS.md` na raiz antes de editar qualquer arquivo. O notebook original em `arquivos_de_contexto/` prevalece para a interpretação do roteiro acadêmico. O notebook principal em `victor_silva_trabalho1.ipynb` é o artefato ativo de desenvolvimento e futura entrega.

## Regras de interpretação

- **Confirmado**: consta expressamente no enunciado, foi verificado no arquivo/dado ou foi decidido pelo responsável.
- **Provisório**: proposta metodológica que ainda pode ser alterada.
- **Pendente**: exige investigação, decisão ou execução.
- **Executado/verificado**: foi efetivamente realizado e há evidência no repositório.

Não misture essas categorias. Não documente propostas como resultados.

## Regras de manutenção

- Mantenha documentos objetivos e sem transcrição desnecessária de conversas.
- Atualize `estado_atual.md` após avanços concretos.
- Registre novas decisões em `decisoes.md`, sem apagar silenciosamente decisões antigas.
- Registre tarefas complexas em `planos_ia/`.
- Transforme procedimentos estáveis e repetíveis em Skills em `skills/`.
- Não afirme que a série prevê LGD: a variável prevista é `Credit`.
- Não altere o raw nem o notebook original do professor.
