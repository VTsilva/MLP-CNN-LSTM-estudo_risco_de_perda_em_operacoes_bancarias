---
name: nome-da-skill
description: Descrição curta e objetiva da atividade padronizada.
---

# Nome da Skill

## Quando utilizar

[Condições específicas para acionar esta Skill.]

## Objetivo

[Resultado esperado.]

## Entradas necessárias

- [Arquivos, dados, parâmetros e contexto.]

## Pré-condições e restrições

- [Requisitos prévios.]
- [Cuidados e ações proibidas.]

## Procedimento

1. [Etapa]
2. [Etapa]
3. [Etapa]

## Padrões de qualidade

- [Critério verificável]

## Saídas esperadas

- [Artefato/resultado]

## Tratamento de erros

[Como agir quando o dado ou contexto não estiver disponível ou estiver inconsistente.]

## Documentação relacionada

- [Caminhos relevantes do projeto.]
