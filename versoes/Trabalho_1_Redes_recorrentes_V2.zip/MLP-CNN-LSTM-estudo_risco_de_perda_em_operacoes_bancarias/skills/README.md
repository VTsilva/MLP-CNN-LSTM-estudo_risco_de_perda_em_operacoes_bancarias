# Skills para agentes e IAs

Skills são instruções reutilizáveis que padronizam como um agente executa uma atividade. Neste projeto, cada Skill fica em seu próprio diretório e possui um arquivo `SKILL.md` com nome, descrição, gatilhos, entradas, pré-condições, procedimento, qualidade e saídas.

## Separação de responsabilidades

- `contexto_ia/`: o que é o projeto, o que sabemos, o estado e decisões vigentes.
- `planos_ia/`: o que será feito em uma tarefa específica.
- `skills/`: como executar procedimentos recorrentes de forma consistente.
- `AGENTS.md`: regras globais para agentes que trabalham no repositório.

## Skills existentes

- `project-context-continuity/SKILL.md`: manter a documentação e continuidade entre sessões/agentes.
- `time-series-data-audit/SKILL.md`: auditar a integridade e regularidade de uma série temporal antes da modelagem.

## Como criar novas Skills

Criar uma Skill somente quando houver um processo recorrente e suficientemente compreendido. Não criar Skills para modelos/etapas ainda não implementados ou testados. Use `TEMPLATE_SKILL.md` e adapte o formato ao ambiente do agente. A existência de `SKILL.md` no repositório não garante que todos os agentes carreguem Skills automaticamente; `AGENTS.md` e o README apontam como consultá-las.
