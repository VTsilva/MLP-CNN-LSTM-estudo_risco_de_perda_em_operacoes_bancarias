---
name: time-series-data-audit
description: Audita integridade, tipos, ordem temporal e regularidade de uma série antes de análise ou modelagem.
---

# Time Series Data Audit

## Quando utilizar

Antes de criar camadas derivadas, executar EDA, gerar janelas supervisionadas ou treinar modelos com uma série temporal.

## Objetivo

Verificar se o conjunto temporal está estruturalmente consistente e documentar problemas que possam afetar a análise ou a avaliação preditiva.

## Entradas necessárias

- Arquivo tabular original ou camada de dados especificada.
- Nome da coluna temporal.
- Frequência esperada, se conhecida.
- Colunas-alvo e explicativas, se já definidas.

## Pré-condições e restrições

- Não sobrescrever a fonte raw.
- Interpretar datas com formato explícito; não depender de inferência ambígua.
- Não preencher ausências ou remover outliers sem regra justificada.
- Não embaralhar a série para executar auditoria.
- Distinguir ausência de linha, valor nulo e frequência irregular.

## Procedimento

1. Registrar caminho, nome, formato, dimensão e data da extração, quando disponível.
2. Ler com tipos controlados e converter a coluna temporal com formato explícito.
3. Verificar valores ausentes por coluna e linhas totalmente vazias.
4. Verificar duplicatas completas e duplicatas da chave temporal.
5. Ordenar cronologicamente em uma cópia de trabalho e verificar se a data já estava ordenada.
6. Calcular diferenças entre timestamps consecutivos e resumir intervalos observados.
7. Comparar os intervalos com a frequência esperada; localizar lacunas e repetições.
8. Verificar tipos, valores não numéricos inesperados, infinitos e cardinalidade.
9. Produzir estatísticas descritivas sem remover observações.
10. Registrar o resultado com contagens e evidência, classificando problemas como erro, exceção ou característica da fonte.
11. Propor correções apenas em camada derivada, documentando regra, motivo e impacto.

## Padrões de qualidade

- Dimensão e schema explicitados.
- Datas min/max, contagem de timestamps únicos e duplicatas reportadas.
- Distribuição dos intervalos temporais reportada.
- Nulos e tipos reportados por coluna.
- Nenhuma limpeza destrutiva aplicada à fonte original.
- Código reexecutável e resultado coerente com a fonte.

## Saídas esperadas

- Relatório de auditoria em Markdown ou notebook.
- Dataset derivado, se autorizado, em camada apropriada da arquitetura Medallion.
- Atualização do dicionário de dados e estado atual, quando necessário.

## Tratamento de erros

Se datas não puderem ser parseadas, listar amostras e interromper a criação de janelas até entender o formato. Se a frequência esperada não estiver definida, descrever a frequência observada sem inventar uma frequência ideal. Se houver duplicatas ou lacunas, não removê-las/preenchê-las automaticamente.

## Documentação relacionada

- `contexto_ia/dicionario_dados.md`
- `contexto_ia/estado_atual.md`
- `contexto_ia/metodologia_provisoria.md`
- `data/README.md`
