---
name: project-context-continuity
description: Mantém a memória documental, os planos e a continuidade do projeto entre sessões e agentes sem duplicar conversas.
---

# Project Context Continuity

## Quando utilizar

Sempre que uma tarefa alterar objetivo, escopo, decisão, estado, artefato, estrutura de pastas ou procedimento recorrente do projeto. Também utilizar ao iniciar uma sessão nova ou assumir o repositório de outro agente.

## Objetivo

Permitir que qualquer agente retome o trabalho com contexto suficiente, rastreabilidade e distinção entre fatos, decisões provisórias e pendências.

## Entradas necessárias

- `AGENTS.md`.
- `README.md`.
- Diretório `contexto_ia/`.
- Plano aplicável em `planos_ia/`.
- Status e diffs do Git.
- Artefatos reais envolvidos na tarefa.

## Pré-condições e restrições

- Não assumir que o resumo de contexto está atualizado sem conferir os arquivos.
- Não inventar resultado nem declarar atividade concluída sem evidência.
- Não apagar decisões antigas silenciosamente.
- Não expor credenciais nem executar push sem autorização.
- Não duplicar transcrições integrais de conversas quando uma decisão consolidada for suficiente.

## Procedimento

1. Ler as instruções de agente e a memória documental na ordem indicada.
2. Verificar a branch, o `git status`, os diffs e os arquivos relevantes antes de editar.
3. Identificar o que é fato confirmado, proposta, pendência e resultado executado.
4. Para tarefas complexas, criar ou atualizar plano com objetivo, escopo, etapas, critérios e riscos.
5. Executar apenas a tarefa autorizada, preservando fontes originais.
6. Registrar no plano os arquivos alterados e as verificações realmente executadas.
7. Atualizar `estado_atual.md` quando o estágio de trabalho mudar.
8. Atualizar `decisoes.md` quando uma decisão for estabelecida ou alterada, com justificativa e status.
9. Atualizar metodologia/dicionário/referências apenas quando seu conteúdo mudar.
10. Ao encerrar, comunicar resumo, evidências, pendências e riscos de forma concisa.

## Padrões de qualidade

- Documentos curtos, específicos e sem contradições.
- Links e caminhos relativos válidos.
- Datas no formato `AAAA-MM-DD`.
- Status explícito.
- Toda afirmação de resultado possui arquivo, saída ou verificação correspondente.
- Mudanças de escopo registradas no histórico de decisões.

## Saídas esperadas

- Contexto atualizado quando necessário.
- Plano atualizado com registro de execução.
- Relato de encerramento da tarefa.

## Tratamento de erros

Se o arquivo esperado estiver ausente, não presumir seu conteúdo. Procurar somente nas fontes disponíveis do repositório; se ainda faltar, registrar bloqueio e perguntar ao responsável pelo projeto.

## Documentação relacionada

- `AGENTS.md`
- `contexto_ia/00_LEIA_PRIMEIRO.md`
- `contexto_ia/estado_atual.md`
- `contexto_ia/decisoes.md`
- `planos_ia/TEMPLATE_PLANO.md`
