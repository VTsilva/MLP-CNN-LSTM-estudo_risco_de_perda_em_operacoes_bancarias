# Instruções para agentes de IA e colaboradores

Este arquivo é a porta de entrada operacional para Devin, outros agentes de desenvolvimento e colaboradores humanos.

## 1. Identidade do projeto

- **Repositório/projeto:** `MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias`
- **GitHub:** https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias
- **Título acadêmico:** Comparação de arquiteturas MLP, CNN e LSTM na previsão de condições de crédito: uma abordagem de séries temporais aplicada ao estudo do risco de perda em operações bancárias.
- **Alvo:** coluna `Credit` do CSV do National Financial Conditions Index (NFCI).
- **Entrega acadêmica exigida:** um único notebook Jupyter chamado `<nome_do_estudante>_trabalho1.ipynb`.

## 2. Leitura obrigatória antes de agir

Leia nesta ordem:

1. `README.md` — visão rápida e estrutura do repositório.
2. `contexto_ia/00_LEIA_PRIMEIRO.md` — roteiro de leitura da memória documental.
3. `contexto_ia/visao_geral.md`.
4. `contexto_ia/estado_atual.md`.
5. `contexto_ia/decisoes.md`.
6. `contexto_ia/enunciado_e_requisitos.md` e `contexto_ia/metodologia_provisoria.md`.
7. `contexto_ia/dicionario_dados.md` e `contexto_ia/referencias.md`.
8. `arquivos_de_contexto/trabalho 1 previsao univariada e multivariada passo unico.ipynb` — roteiro original do professor; é a referência primária para as exigências da disciplina.
9. Planos aplicáveis em `planos_ia/` e Skills aplicáveis em `skills/`.

Se houver conflito, preserve o material original do professor e sinalize o conflito. Não transforme hipótese ou proposta em decisão confirmada sem autorização do responsável pelo projeto.

## 3. Regras de trabalho

- Preserve `data/raw/nfci-data-series-csv.csv` como fonte original. Nunca sobrescreva o arquivo raw com dados tratados.
- Preserve o notebook original do professor. Para desenvolvimento, crie uma cópia na raiz com o nome final solicitado quando for a etapa apropriada.
- Não invente resultados, estatísticas, referências, execuções, métricas, interpretações ou decisões.
- Diferencie claramente: **confirmado**, **provisório**, **pendente** e **executado/verificado**.
- Mantenha a ordem cronológica ao dividir a série. Não embaralhe a série bruta antes da divisão nem antes da criação das janelas.
- Faça qualquer scaler/normalizador ser ajustado somente com a parte de treinamento. Aplique os parâmetros aprendidos a validação e teste.
- Garanta que cada amostra de previsão use apenas observações disponíveis antes do instante previsto. Nenhuma janela pode usar o valor futuro como entrada.
- O alvo é `Credit`, não LGD. O contexto de risco de perda/LGD é motivação econômica; não alegue que o modelo estima LGD.
- Não selecione hiperparâmetros ou épocas com base no conjunto de teste. Use treino/validação para escolhas; reserve teste para avaliação final, respeitando e explicando o roteiro da disciplina.
- O roteiro pede “acurácia” em um problema de previsão contínua. Antes de definir essa métrica, investigue o material/código utilizado em aula e registre uma definição operacional defensável. Não reporte acurácia de classificação como se fosse métrica natural de regressão.
- Execute e valide células do notebook em ordem. Não deixe células com resultados antigos que não correspondam ao código atual.
- Prefira código reprodutível, funções reutilizáveis, nomes claros, comentários relevantes e gráficos legíveis.
- Não adicione dependências sem necessidade. Registre as dependências efetivamente utilizadas em `requirements.txt` quando a implementação começar.

## 4. Planejamento, contexto e Skills

Para tarefa complexa ou com várias etapas:

1. Crie/atualize um plano em `planos_ia/` antes da execução.
2. Execute somente o escopo autorizado.
3. Registre arquivos alterados, comandos/testes e resultados no plano.
4. Atualize `contexto_ia/estado_atual.md` e `contexto_ia/decisoes.md` quando o estado ou as decisões mudarem.
5. Atualize a Skill correspondente se um procedimento reutilizável tiver sido validado.

Não use `contexto_ia/` como diário de conversa. Mantenha documentos curtos, consolidados e sem duplicação desnecessária.

## 5. Git e segurança

- O repositório tem `origin` configurado para o endereço GitHub listado acima.
- **Não faça `git push`, não crie releases e não altere o repositório remoto sem autorização explícita do responsável.**
- Não reescreva histórico (`reset --hard`, `rebase` destrutivo, force push) nem descarte mudanças existentes sem autorização.
- Antes de editar, verifique `git status`, branch e diffs. Preserve mudanças não relacionadas.
- Não inclua tokens, senhas, arquivos `.env`, credenciais ou dados pessoais nos commits.
- Para mudanças relevantes, sugira uma mensagem de commit, mas não faça push sem solicitação.

## 6. Entrega e padrão de qualidade

A entrega formal da disciplina é somente o notebook final. Diretórios de dados, planos, Skills e contexto dão suporte ao desenvolvimento, mas não devem ser confundidos com itens exigidos para envio acadêmico.

O notebook final deve:

- explicar a série, fonte, variáveis e tratamentos;
- apresentar EDA, gráficos, tendências/ciclos quando sustentados pelos dados;
- documentar janela temporal e divisão cronológica 70/20/10;
- incluir todos os modelos pedidos nos experimentos univariado e multivariado;
- mostrar curvas de custo e métrica acompanhadas em treino e validação;
- justificar manualmente a quantidade de épocas;
- reportar métricas de treino, validação e teste;
- comparar modelos com tabelas e elementos visuais;
- discutir limitações, principalmente a distinção entre previsão do índice `Credit` e estimação de LGD;
- executar integralmente, sem erros e com resultados coerentes com o código.

## 7. Comunicação ao responsável

Ao terminar uma tarefa, resuma: o que foi feito, arquivos alterados, validações executadas, resultados reais, decisões tomadas e pendências. Se a tarefa não puder ser concluída, informe exatamente o que faltou e não simule conclusão.
