# Planos de execução

Registre aqui planos de tarefas relevantes. Um plano descreve objetivo, escopo, arquivos, etapas, critérios de conclusão, riscos e resultado da execução. Ele não substitui a memória consolidada em `contexto_ia/`.

## Convenção

`AAAA-MM-DD_nome-curto-da-tarefa.md`

## Status

- `Proposto`: sugestão ainda não autorizada/iniciada.
- `Planejado`: escopo aprovado, aguardando execução.
- `Em andamento`: execução iniciada.
- `Concluído`: critérios de conclusão cumpridos e evidências registradas.
- `Bloqueado`: existe impedimento documentado.
- `Cancelado`: tarefa não será executada.

## Planos atuais

- `2026-11-07_consolidacao_identidade_contexto_e_requisitos.md` — concluído.
- `PROPOSTA_01_EDA_E_CARACTERIZACAO_TEMPORAL.md` — proposta de próxima etapa, ainda não executada.

Use `TEMPLATE_PLANO.md` para novos planos.
