# Estado atual do projeto

**Data da fotografia documental:** 07/11/2026.

## Estado geral

O projeto foi nomeado, vinculado ao repositório GitHub pessoal e teve sua estrutura documental alinhada ao enunciado do professor. O dataset original e o notebook de referência estão armazenados. A análise exploratória, o pipeline Medallion derivado, a modelagem e o notebook final ainda não foram executados/desenvolvidos.

## Identidade e versionamento

- Repositório: `MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias`.
- URL: https://github.com/VTsilva/MLP-CNN-LSTM-estudo_risco_de_perda_em_operacoes_bancarias
- O snapshot recebido contém metadados Git, branch local `main` e `origin` configurado para a URL acima.
- O último commit local visível no snapshot recebido era `2afc97d` (`Estruturando o projeto com IA 🚀`). A atualização documental desta versão é uma mudança de trabalho; não foi feito push para o GitHub.
- Sempre conferir `git status`, branch e diffs antes de continuar. Nunca presumir que o remoto está atualizado apenas porque existe `origin`.

## Base de dados — validação concluída

Arquivo original: `data/raw/nfci-data-series-csv.csv`.

Verificações executadas diretamente no CSV:

| Verificação | Resultado |
|---|---:|
| Linhas de dados | 2.913 |
| Colunas | 7 |
| Data inicial | 08/01/1971 |
| Data final | 30/10/2026 |
| Datas únicas | 2.913 |
| Datas duplicadas | 0 |
| Valores ausentes | 0 em todas as colunas |
| Intervalo entre datas consecutivas | 7 dias em 2.912 intervalos |
| Frequência observada | Semanal regular |

Colunas: `Friday_of_Week`, `NFCI`, `ANFCI`, `Risk`, `Credit`, `Leverage`, `Nonfinancial_Leverage`.

A coluna de data está em texto no padrão `MM/DD/YYYY` no CSV. Exemplo: `01/08/1971` representa 8 de janeiro de 1971. As seis demais colunas foram lidas como numéricas (`float64`) na verificação realizada.

## Artefatos presentes

- `data/raw/nfci-data-series-csv.csv`: CSV original.
- `arquivos_de_contexto/trabalho 1 previsao univariada e multivariada passo unico.ipynb`: roteiro/notebook original do professor, preservado sem edição.
- `arquivos_de_contexto/enunciado_e_requisitos.md`: síntese/transcrição do enunciado para consulta por agentes.
- `contexto_ia/`: visão geral, decisões, metodologia, dicionário, referências e estado.
- `planos_ia/`: plano de consolidação concluído, proposta de plano para EDA e templates.
- `skills/`: Skills operacionais de continuidade documental e auditoria de dados temporais.
- `AGENTS.md`: instruções operacionais para Devin e outros agentes.

## Atividades concluídas

- [x] Identificação do nome do projeto e do repositório GitHub.
- [x] Consolidação do título e da descrição acadêmica.
- [x] Inspeção do ZIP e da estrutura atual recebida.
- [x] Inspeção do notebook original do professor.
- [x] Validação estrutural do CSV: dimensão, nulos, duplicatas, datas e regularidade semanal.
- [x] Formalização dos experimentos univariado e multivariado e das arquiteturas listadas no roteiro.
- [x] Criação/atualização das instruções para agentes, contexto, planos e Skills.

## Atividades ainda não executadas

- [ ] Análise exploratória (estatísticas, gráficos, tendência, ciclos, autocorrelação e outras análises justificadas).
- [ ] Criação do dataset Bronze.
- [ ] Criação do dataset Silver.
- [ ] Decisão final sobre colunas do experimento multivariado.
- [ ] Definição fundamentada do tamanho da janela.
- [ ] Definição e documentação dos transformadores de escala.
- [ ] Fechamento da métrica operacional chamada “acurácia” no roteiro.
- [ ] Criação das janelas e partições sem vazamento temporal.
- [ ] Implementação e treinamento dos 8 modelos univariados.
- [ ] Implementação e treinamento dos 8 modelos multivariados.
- [ ] Comparação, discussão final e identificação do melhor desempenho.
- [ ] Desenvolvimento e execução integral do notebook final `<nome_do_estudante>_trabalho1.ipynb`.

## Próxima etapa sugerida

Executar a análise exploratória e auditoria da série, seguindo o plano proposto em `planos_ia/PROPOSTA_01_EDA_E_CARACTERIZACAO_TEMPORAL.md`. O plano está proposto e ainda aguarda direcionamento do responsável; não foi executado.
