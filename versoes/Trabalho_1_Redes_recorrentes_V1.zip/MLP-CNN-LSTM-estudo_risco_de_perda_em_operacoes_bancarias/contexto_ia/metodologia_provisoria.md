# Metodologia experimental — versão provisória

Este documento traduz os requisitos acadêmicos em um desenho de execução. Pontos marcados como pendentes devem ser resolvidos antes de congelar a implementação.

## 1. Problema e target

- Tarefa: previsão de série temporal contínua, um passo à frente.
- Target: `Credit`.
- Frequência: semanal.
- Horizonte: próximo registro semanal.
- Unidade temporal: observação por sexta-feira da semana.

A previsão de `Credit` não é uma estimativa direta de LGD. A conexão com LGD fica na discussão de contexto de risco financeiro e condições de crédito.

## 2. Experimentos

### 2.1 Univariado

Usar apenas a sequência histórica de `Credit` para prever o próximo valor de `Credit`.

Modelos exigidos pelo notebook:

1. MLP de 1 camada.
2. MLP de 2 camadas.
3. CNN.
4. LSTM.
5. Stacked LSTM de 2 camadas.
6. LSTM bidirecional.
7. CNN-LSTM.
8. ConvLSTM.

### 2.2 Multivariado, saída única

Usar sequência histórica de `Credit` e de outras variáveis aprovadas como entradas; prever somente o próximo valor de `Credit`.

Features candidatas iniciais, ainda sujeitas à EDA:

- `Credit` (histórico do próprio target).
- `Risk`.
- `Leverage`.
- `Nonfinancial_Leverage`.

`NFCI` e `ANFCI` ficam fora do desenho inicial por serem índices agregados/ajustados com sobreposição conceitual e potencial redundância com os componentes. Qualquer inclusão deve ser justificável e avaliada separadamente.

Modelos exigidos pelo notebook:

1. MLP de 1 camada.
2. MLP de 2 camadas.
3. MLP multi-cabeça de 1 camada.
4. CNN.
5. CNN multi-cabeça.
6. LSTM.
7. Stacked LSTM de 2 camadas.
8. LSTM bidirecional.

A definição exata de cada modelo multi-cabeça deve seguir os exemplos de aula e ser documentada; não presumir uma arquitetura sem conferir os materiais.

## 3. Análise exploratória

Antes do treinamento, descrever:

- número de observações, variáveis, período e frequência;
- tipos de dados, ausências, duplicatas e regularidade dos intervalos;
- estatísticas descritivas por variável;
- séries temporais individuais e comparações em escalas apropriadas;
- tendências de longo prazo e mudanças de regime;
- ciclos e padrões recorrentes, se sustentados por evidência;
- médias móveis e dispersão móvel, se úteis;
- autocorrelação (ACF) e, quando pertinente, PACF;
- relações/correlações entre variáveis, com cuidado para não interpretar correlação como causalidade;
- estacionariedade e necessidade (ou não) de transformação, com justificativa.

Não afirmar sazonalidade apenas porque há oscilações visuais. Separar tendência, ciclo, sazonalidade e mudanças de regime.

## 4. Divisão temporal

Aplicar 70% iniciais para treino, 20% seguintes para validação e 10% finais para teste. Não embaralhar a série bruta antes da partição.

Para o arquivo atual com 2.913 registros, um particionamento por índices de corte `floor(0.70*N)` e `floor(0.90*N)` gera, antes da criação de janelas:

- treino: 2.039 observações (índices 0 a 2.038);
- validação: 582 observações (índices 2.039 a 2.620);
- teste: 292 observações (índices 2.621 a 2.912).

Os limites exatos devem ser calculados por código e registrados no notebook. A contagem de amostras supervisionadas após criação de janelas será menor e dependerá do tamanho da janela.

### Janelas e fronteiras

- A janela deve conter somente observações anteriores ao target previsto.
- Nenhum target de validação/teste pode ser usado para ajustar o modelo.
- É metodologicamente aceitável usar valores históricos anteriores como contexto de uma janela de validação/teste, desde que esses valores estivessem disponíveis no instante da previsão e não sejam usados como target de treino naquela amostra.
- Definir claramente se os alvos de cada partição permanecem integralmente dentro da partição correspondente.
- O tamanho da janela permanece pendente; justificar com EDA, padrões temporais e/ou comparação controlada.

### Embaralhamento

O notebook original menciona embaralhar o treinamento após a divisão. Preservar primeiro a cronologia e criar as janelas. Se o embaralhamento for aplicado para o otimizador, embaralhar somente a ordem das amostras/janelas de treinamento; nunca inverter a ordem temporal dentro de cada janela e nunca embaralhar validação/teste. Confirmar a interpretação com materiais de aula, se disponíveis.

## 5. Pré-processamento e prevenção de vazamento

- Converter `Friday_of_Week` para datetime com formato explícito `%m/%d/%Y`.
- Manter observações em ordem crescente de data.
- Preservar o CSV original em `raw/`.
- Registrar qualquer transformação em Bronze/Silver/Gold.
- Ajustar scalers/transformadores somente usando dados de treino (ou a faixa de treino definida para o experimento).
- Aplicar os parâmetros aprendidos, sem reajuste, em validação e teste.
- Comparar resultados na escala transformada somente para diagnóstico interno, mas reportar erros também na escala original do `Credit` sempre que possível.
- Não usar valores futuros, estatísticas calculadas sobre o dataset inteiro ou informação do teste para seleção de features, scaler, janela ou hiperparâmetros.

## 6. Treinamento e escolha de épocas

Para cada arquitetura:

1. Definir e registrar arquitetura, parâmetros, inicialização, loss, otimizador, batch size, seed e demais hiperparâmetros.
2. Executar treinamento inicial monitorando a função de custo e a métrica escolhida em treino e validação a cada época.
3. Plotar curvas de treinamento e validação.
4. Inspecionar manualmente a evolução e identificar overfitting (por exemplo, erro de treino segue caindo enquanto erro de validação aumenta de modo persistente) ou plateau de validação.
5. Registrar o número de épocas escolhido e a justificativa visual.
6. Retreinar conforme o procedimento aprovado e calcular desempenho em treino, validação e teste.
7. Manter o teste fora das decisões de arquitetura/época/hiperparâmetro; usá-lo para a avaliação final e comparação reportada.

A política exata do retreinamento (reinicializar pesos e treinar pelo número selecionado; ou outra prática ensinada) deve seguir o material de aula e ser documentada. Não incorporar validação ao ajuste se isso impedir a apresentação de sua métrica separada exigida pelo professor, salvo decisão explícita e protocolo que preserve uma avaliação válida.

## 7. Métricas

O enunciado usa “acurácia” para uma saída contínua. Confirmar a definição com o conteúdo do curso antes de implementar esse item.

Como métricas de regressão, considerar:

- MAE: erro absoluto médio, interpretável na unidade do índice.
- MSE: erro quadrático médio, também usado como função de custo em certas configurações.
- RMSE: raiz do MSE, na unidade do índice e com maior penalização para erros grandes.
- R², se útil, lembrando que pode ser negativo em teste.
- Acurácia direcional, apenas como métrica complementar e definida claramente (por exemplo, acerto na direção da variação), não como substituta de erro de magnitude.

Evitar MAPE como métrica principal porque a série `Credit` pode assumir valores negativos e próximos de zero.

Definir antecipadamente uma métrica primária para comparar modelos e justificar a escolha. Reportar métricas de treino, validação e teste sem misturar escalas.

## 8. Comparação e comunicação

- Comparar modelos univariados entre si.
- Comparar modelos multivariados entre si.
- Comparar melhor univariado versus melhor multivariado.
- Apresentar tabela consolidada com métrica, época escolhida e arquitetura.
- Incluir gráficos de curvas de treino/validação e previsões versus valores reais no teste.
- Apresentar limitações, estabilidade, complexidade e possíveis sinais de overfitting.
- Escolher o melhor modelo com base em critérios explícitos, não apenas em afirmações visuais.

## 9. Decisões ainda abertas

- tamanho da janela;
- seleção final das features multivariadas;
- métrica exata de “acurácia” do curso e métrica primária;
- estratégia de scaling;
- loss, otimizador, batch size, seeds e hiperparâmetros;
- detalhes das arquiteturas multi-cabeça, ConvLSTM e CNN-LSTM;
- política exata de retreinamento depois da inspeção das épocas.
